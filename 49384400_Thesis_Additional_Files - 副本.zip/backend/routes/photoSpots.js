import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';

const router = Router();
const dataPath = path.join(process.cwd(), 'data', 'brisbane_photo_spots.json');
const photoSpots = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));

router.get('/', (_req, res) => {
  res.json({ count: photoSpots.length, items: photoSpots });
});

export { router as photoSpotsRouter, photoSpots };
