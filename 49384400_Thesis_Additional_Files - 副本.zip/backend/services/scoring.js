const EARTH_RADIUS_KM = 6371;

function toRadians(value) {
  return (value * Math.PI) / 180;
}

export function haversineDistanceKm(lat1, lng1, lat2, lng2) {
  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_KM * c;
}

export function estimateTravelMinutes(distanceKm, transportMode = 'driving') {
  const speeds = {
    walking: 4.8,
    cycling: 15,
    driving: 30,
    transit: 24,
  };
  const speed = speeds[transportMode] ?? speeds.driving;
  const rawMinutes = (distanceKm / speed) * 60;
  return Math.max(5, Math.round(rawMinutes));
}

export function scoreSpot({
  spot,
  preferredTags = [],
  preferredTime = 'sunset',
  startLocation,
}) {
  const tagMatches = preferredTags.filter((tag) => spot.tags.includes(tag)).length;
  const tagScore = preferredTags.length === 0 ? 0.6 : tagMatches / preferredTags.length;
  const popularityScore = Math.min(1, (spot.popularity ?? 50) / 100);
  const lightingScore = spot.best_time?.includes(preferredTime) ? 1 : 0.35;

  let proximityScore = 0.6;
  let distanceKm = null;
  if (startLocation?.lat && startLocation?.lng) {
    distanceKm = haversineDistanceKm(startLocation.lat, startLocation.lng, spot.lat, spot.lng);
    proximityScore = Math.max(0, 1 - distanceKm / 20);
  }

  const totalScore =
    0.35 * tagScore +
    0.25 * popularityScore +
    0.25 * lightingScore +
    0.15 * proximityScore;

  return {
    spot,
    distanceKm,
    score: Number(totalScore.toFixed(3)),
    breakdown: {
      tagScore: Number(tagScore.toFixed(3)),
      popularityScore: Number(popularityScore.toFixed(3)),
      lightingScore: Number(lightingScore.toFixed(3)),
      proximityScore: Number(proximityScore.toFixed(3)),
    },
  };
}

export function buildSimpleItinerary(recommendations, startLocation, transportMode, availableMinutes = 240) {
  const remaining = [...recommendations].sort((a, b) => b.score - a.score);
  const itinerary = [];
  let currentPoint = startLocation;
  let usedMinutes = 0;

  while (remaining.length > 0) {
    const feasible = remaining
      .map((item) => {
        const from = currentPoint ?? item.spot;
        const distanceKm = currentPoint
          ? haversineDistanceKm(from.lat, from.lng, item.spot.lat, item.spot.lng)
          : item.distanceKm ?? 0;
        const travelMinutes = estimateTravelMinutes(distanceKm, transportMode);
        const visitMinutes = item.spot.average_visit_minutes ?? 30;
        return { ...item, distanceKmFromCurrent: distanceKm, travelMinutes, visitMinutes };
      })
      .sort((a, b) => {
        const aValue = a.score - a.travelMinutes / 200;
        const bValue = b.score - b.travelMinutes / 200;
        return bValue - aValue;
      });

    const next = feasible.find((item) => usedMinutes + item.travelMinutes + item.visitMinutes <= availableMinutes);
    if (!next) break;

    usedMinutes += next.travelMinutes + next.visitMinutes;
    itinerary.push({
      id: next.spot.id,
      name: next.spot.name,
      lat: next.spot.lat,
      lng: next.spot.lng,
      travelMinutes: next.travelMinutes,
      visitMinutes: next.visitMinutes,
      cumulativeMinutes: usedMinutes,
      score: next.score,
      bestTime: next.spot.best_time,
      tags: next.spot.tags,
      description: next.spot.description,
    });

    currentPoint = { lat: next.spot.lat, lng: next.spot.lng };
    const index = remaining.findIndex((item) => item.spot.id === next.spot.id);
    remaining.splice(index, 1);
  }

  return {
    itinerary,
    summary: {
      stopCount: itinerary.length,
      usedMinutes,
      remainingMinutes: Math.max(0, availableMinutes - usedMinutes),
    },
  };
}
