export async function getSunContext(lat, lng) {
  const url = new URL('https://api.sunrise-sunset.org/json');
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lng', String(lng));
  url.searchParams.set('formatted', '0');

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Sun API failed: ${response.status}`);
  }

  const data = await response.json();
  return data.results;
}

export async function getWeatherContext(lat, lng, apiKey) {
  if (!apiKey) {
    return null;
  }

  const url = new URL('https://api.openweathermap.org/data/2.5/weather');
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lon', String(lng));
  url.searchParams.set('appid', apiKey);
  url.searchParams.set('units', 'metric');

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`OpenWeather failed: ${response.status}`);
  }

  return response.json();
}
