import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const spotsPath = path.join(__dirname, "data", "brisbane_photo_spots.json");

function loadSpots() {
  const raw = fs.readFileSync(spotsPath, "utf-8");
  return JSON.parse(raw);
}

function toMinutes(timeStr) {
  const [h, m] = String(timeStr).split(":").map(Number);
  return h * 60 + m;
}

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function normalizeScore(value, min = 0, max = 100) {
  if (!Number.isFinite(value)) return 0;
  if (value <= min) return 0;
  if (value >= max) return 1;
  return (value - min) / (max - min);
}

function getTimeCategory(preferences) {
  const tags = preferences?.preferred_tags || [];

  if (tags.includes("sunrise")) return "sunrise";
  if (tags.includes("sunset")) return "sunset";
  if (tags.includes("night")) return "night";

  const start = preferences?.start_time || "15:00";
  const minutes = toMinutes(start);

  if (minutes < 420) return "sunrise";
  if (minutes >= 960 && minutes <= 1140) return "sunset";
  if (minutes > 1140) return "night";
  return "daytime";
}

function getPhotoStyleFromTags(tags = []) {
  const styles = [];

  if (tags.includes("sunset") && tags.includes("city")) styles.push("sunset_skyline");
  if (tags.includes("night") && tags.includes("city")) styles.push("night_cityscape");
  if (tags.includes("river")) styles.push("river_reflection");
  if (tags.includes("architecture")) styles.push("architecture");
  if (tags.includes("lookout")) styles.push("lookout");
  if (tags.includes("nature")) styles.push("nature_walk");
  if (tags.includes("bridge")) styles.push("bridge_view");

  return [...new Set(styles)];
}

function computePhotoStyleMatch(spot, preferences) {
  const userStyles = getPhotoStyleFromTags(preferences?.preferred_tags || []);
  const spotStyles = spot.photo_styles || [];

  if (!userStyles.length || !spotStyles.length) return 0;

  const matches = userStyles.filter((s) => spotStyles.includes(s)).length;
  return matches / userStyles.length;
}

function computeTagMatch(spot, preferences) {
  const prefTags = preferences?.preferred_tags || [];
  const spotTags = spot.tags || [];

  if (!prefTags.length || !spotTags.length) return 0;

  const matches = prefTags.filter((tag) => spotTags.includes(tag)).length;
  return matches / prefTags.length;
}

function computeTimeMatch(spot, preferences) {
  const timeCategory = getTimeCategory(preferences);

  if (timeCategory === "sunset") {
    return normalizeScore(Number(spot.golden_hour_score || 0));
  }

  if (timeCategory === "night") {
    return normalizeScore(Number(spot.night_score || 0));
  }

  if (timeCategory === "sunrise") {
    if ((spot.best_time || []).includes("sunrise")) return 0.9;
    if ((spot.best_time || []).includes("morning")) return 0.7;
    return 0.2;
  }

  if ((spot.best_time || []).includes("daytime")) return 0.8;
  if ((spot.best_time || []).includes("morning")) return 0.6;
  return 0.4;
}

function computeWeatherSuitability(spot, weatherData) {
  if (!weatherData) return 0.5;

  const cloud = Number(weatherData.clouds_percent ?? 50);
  const rainProb = Number(weatherData.rain_probability_percent ?? 0);
  const visibilityKm = Number(weatherData.visibility_km ?? 10);

  const pref = spot.weather_preferences || {};
  const maxCloud = Number(pref.max_cloud_cover ?? 100);
  const maxRain = Number(pref.max_rain_probability ?? 100);
  const minVisibility = Number(pref.min_visibility_km ?? 0);

  let score = 1;

  if (cloud > maxCloud) {
    score -= Math.min((cloud - maxCloud) / 100, 0.35);
  }

  if (rainProb > maxRain) {
    score -= Math.min((rainProb - maxRain) / 100, 0.45);
  }

  if (visibilityKm < minVisibility) {
    score -= Math.min((minVisibility - visibilityKm) / 10, 0.35);
  }

  const styles = spot.photo_styles || [];

  if (styles.includes("sunset_skyline")) {
    if (cloud > 80) score -= 0.15;
    if (visibilityKm < 5) score -= 0.15;
  }

  if (styles.includes("night_cityscape")) {
    if (rainProb > 50) score -= 0.2;
    if (visibilityKm < 4) score -= 0.1;
  }

  if (styles.includes("river_reflection")) {
    if (rainProb > 50) score -= 0.15;
  }

  score = Math.max(0, Math.min(1, score));
  return score;
}

function computePopularityScore(spot) {
  return normalizeScore(Number(spot.popularity || 0));
}

function computeProximityScore(startLocation, spot) {
  const distanceKm = haversineKm(
    Number(startLocation.lat),
    Number(startLocation.lng),
    Number(spot.lat),
    Number(spot.lng)
  );

  const proximity = Math.max(0, 1 - distanceKm / 20);

  return {
    proximityScore: proximity,
    distanceKm
  };
}

async function fetchWeatherContext(lat, lng) {
  try {
    const key = process.env.OPENWEATHER_API_KEY;
    if (!key) return null;

    const url =
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}` +
      `&appid=${key}&units=metric`;

    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok) {
      console.error("Weather context fetch failed:", data);
      return null;
    }

    return {
      description: data.weather?.[0]?.description ?? "",
      temperature_c: data.main?.temp ?? null,
      clouds_percent: data.clouds?.all ?? null,
      visibility_km: data.visibility ? Number((data.visibility / 1000).toFixed(1)) : 10,
      rain_probability_percent: data.rain?.["1h"] ? 60 : 0
    };
  } catch (error) {
    console.error("Weather context error:", error);
    return null;
  }
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true });
});

app.get("/api/spots", (req, res) => {
  try {
    const spots = loadSpots();
    res.json(spots);
  } catch (error) {
    console.error("Failed to load spots:", error);
    res.status(500).json({ error: "Failed to load spots data" });
  }
});

app.get("/api/weather", async (req, res) => {
  try {
    const { lat, lng } = req.query;
    const key = process.env.OPENWEATHER_API_KEY;

    if (!lat || !lng) {
      return res.status(400).json({ error: "lat and lng are required" });
    }

    if (!key) {
      return res.json({
        description: "Weather API key missing",
        temperature_c: null,
        clouds_percent: null
      });
    }

    const url =
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}` +
      `&appid=${key}&units=metric`;

    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok) {
      console.error("OpenWeather error:", data);
      return res.status(response.status).json({
        error: data.message || "Failed to fetch weather",
        details: data
      });
    }

    res.json({
      description: data.weather?.[0]?.description ?? "N/A",
      temperature_c: data.main?.temp ?? null,
      clouds_percent: data.clouds?.all ?? null,
      visibility_km: data.visibility ? Number((data.visibility / 1000).toFixed(1)) : null,
      rain_probability_percent: data.rain?.["1h"] ? 60 : 0
    });
  } catch (error) {
    console.error("Weather error:", error);
    res.status(500).json({ error: "Failed to fetch weather" });
  }
});

app.get("/api/sun", async (req, res) => {
  try {
    const { lat, lng } = req.query;

    if (!lat || !lng) {
      return res.status(400).json({ error: "lat and lng are required" });
    }

    const url = `https://api.sunrise-sunset.org/json?lat=${lat}&lng=${lng}&formatted=0`;
    const response = await fetch(url);
    const data = await response.json();

    if (!response.ok || data.status !== "OK") {
      console.error("Sun API error:", data);
      return res.status(500).json({
        error: "Failed to fetch sun data",
        details: data
      });
    }

    const sunrise = data.results?.sunrise
      ? new Date(data.results.sunrise).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        })
      : null;

    const sunset = data.results?.sunset
      ? new Date(data.results.sunset).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        })
      : null;

    res.json({
      sunrise_local: sunrise,
      sunset_local: sunset
    });
  } catch (error) {
    console.error("Sun error:", error);
    res.status(500).json({ error: "Failed to fetch sun data" });
  }
});

app.post("/api/recommend", async (req, res) => {
  try {
    const spots = loadSpots();

    const preferences = req.body || {};
    const {
      start_time = "15:00",
      end_time = "20:00",
      max_locations = 4,
      start_location = { lat: -27.4698, lng: 153.0251 }
    } = preferences;

    const startMinutes = toMinutes(start_time);
    const endMinutes = toMinutes(end_time);
    const totalAvailable = Math.max(endMinutes - startMinutes, 0);

    const weatherContext = await fetchWeatherContext(
      Number(start_location.lat),
      Number(start_location.lng)
    );

    const scored = spots.map((spot) => {
      const tagMatch = computeTagMatch(spot, preferences);
      const photoStyleMatch = computePhotoStyleMatch(spot, preferences);
      const timeMatch = computeTimeMatch(spot, preferences);
      const weatherSuitability = computeWeatherSuitability(spot, weatherContext);
      const popularityScore = computePopularityScore(spot);

      const { proximityScore, distanceKm } = computeProximityScore(start_location, spot);

      const finalScore =
        0.22 * tagMatch +
        0.23 * photoStyleMatch +
        0.20 * timeMatch +
        0.18 * weatherSuitability +
        0.10 * popularityScore +
        0.07 * proximityScore;

      return {
        ...spot,
        distance_km: Number(distanceKm.toFixed(2)),
        score: Number((finalScore * 100).toFixed(2)),
        explainability: {
          tag_match: Number((tagMatch * 100).toFixed(1)),
          photo_style_match: Number((photoStyleMatch * 100).toFixed(1)),
          time_match: Number((timeMatch * 100).toFixed(1)),
          weather_suitability: Number((weatherSuitability * 100).toFixed(1)),
          popularity_score: Number((popularityScore * 100).toFixed(1)),
          proximity_score: Number((proximityScore * 100).toFixed(1))
        }
      };
    });

    scored.sort((a, b) => b.score - a.score);

    let usedMinutes = 0;
    const picked = [];

    for (const spot of scored) {
      const stay = Number(spot.average_visit_minutes || 30);
      const estimatedTravel = 20;

      if (picked.length >= max_locations) break;

      if (usedMinutes + stay + estimatedTravel > totalAvailable && picked.length > 0) {
        continue;
      }

      picked.push(spot);
      usedMinutes += stay + estimatedTravel;
    }

    res.json({
      weather_context: weatherContext,
      recommendations: picked
    });
  } catch (error) {
    console.error("Recommend error:", error);
    res.status(500).json({ error: "Failed to recommend spots" });
  }
});

app.post("/api/directions", async (req, res) => {
  try {
    const mapboxToken = process.env.MAPBOX_ACCESS_TOKEN;
    const { startLocation, recommendations = [], profile = "driving" } = req.body || {};

    if (!mapboxToken) {
      return res.status(500).json({ error: "MAPBOX_ACCESS_TOKEN is missing" });
    }

    if (
      !startLocation ||
      !Number.isFinite(Number(startLocation.lng)) ||
      !Number.isFinite(Number(startLocation.lat))
    ) {
      return res.status(400).json({ error: "Valid startLocation is required" });
    }

    const validStops = recommendations.filter(
      (spot) =>
        Number.isFinite(Number(spot.lng)) && Number.isFinite(Number(spot.lat))
    );

    if (validStops.length === 0) {
      return res.json({
        routeGeoJSON: null,
        orderedRecommendations: [],
        distance_km: 0,
        duration_min: 0
      });
    }

    const trimmedStops = validStops.slice(0, 11);

    const coords = [
      `${Number(startLocation.lng)},${Number(startLocation.lat)}`,
      ...trimmedStops.map((spot) => `${Number(spot.lng)},${Number(spot.lat)}`)
    ];

    const safeProfile = ["driving", "walking", "cycling", "driving-traffic"].includes(profile)
      ? profile
      : "driving";

    const optimizationUrl =
      `https://api.mapbox.com/optimized-trips/v1/mapbox/${safeProfile}/${coords.join(";")}` +
      `?geometries=geojson&overview=full&steps=true&roundtrip=false&source=first&destination=last&access_token=${mapboxToken}`;

    const response = await fetch(optimizationUrl);
    const data = await response.json();

    if (!response.ok) {
      console.error("Mapbox Optimization error:", data);
      return res.status(response.status).json({
        error: data.message || "Optimization request failed",
        details: data
      });
    }

    const trip = data.trips?.[0];
    if (!trip?.geometry) {
      return res.status(500).json({
        error: "No optimized trip geometry returned from Mapbox"
      });
    }

    const orderedRecommendations = trimmedStops
      .map((spot, idx) => {
        const wp = data.waypoints?.[idx + 1];
        return {
          ...spot,
          snapped_location: wp?.location || [spot.lng, spot.lat],
          waypoint_index: Number.isFinite(wp?.waypoint_index) ? wp.waypoint_index : idx + 1
        };
      })
      .sort((a, b) => a.waypoint_index - b.waypoint_index)
      .map(({ waypoint_index, ...spot }) => spot);

    res.json({
      routeGeoJSON: {
        type: "Feature",
        geometry: trip.geometry,
        properties: {}
      },
      orderedRecommendations,
      distance_km: Number(((trip.distance || 0) / 1000).toFixed(2)),
      duration_min: Number(((trip.duration || 0) / 60).toFixed(1))
    });
  } catch (error) {
    console.error("Directions error:", error);
    res.status(500).json({ error: "Failed to fetch directions" });
  }
});

app.post("/api/ai-summary", async (req, res) => {
  try {
    const { preferences, recommendations = [] } = req.body || {};
    const key = process.env.DEEPSEEK_API_KEY;

    if (!recommendations.length) {
      return res.json({ summary: "No itinerary available yet." });
    }

    const names = recommendations.map((r) => r.name).join(", ");

    if (!key) {
      return res.json({
        summary: `This itinerary includes ${names}. It is arranged based on your selected photography preferences, location popularity, and travel convenience.`
      });
    }

    const prompt = `
You are a travel assistant.
Write a short trip summary in clear English for a photography-focused traveler in Brisbane.

User preferences:
${JSON.stringify(preferences, null, 2)}

Recommended spots:
${JSON.stringify(
  recommendations.map((r) => ({
    name: r.name,
    tags: r.tags,
    photo_styles: r.photo_styles,
    best_time: r.best_time,
    distance_km: r.distance_km,
    explainability: r.explainability
  })),
  null,
  2
)}

Requirements:
- Keep it under 120 words
- No markdown symbols
- Natural and helpful
- Mention why these places fit the trip
`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    let response;
    let data;

    try {
      response = await fetch("https://api.deepseek.com/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`
        },
        body: JSON.stringify({
          model: "deepseek-v4-flash",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7
        }),
        signal: controller.signal
      });

      data = await response.json();
    } catch (error) {
      clearTimeout(timeout);
      console.error("AI summary network error:", error);

      return res.json({
        summary: `This itinerary includes ${names}. It is arranged based on your selected photography preferences, location popularity, and travel convenience.`
      });
    }

    clearTimeout(timeout);

    if (!response.ok) {
      console.error("DeepSeek API error:", data);
      return res.json({
        summary: `This itinerary includes ${names}. It is arranged based on your selected photography preferences, location popularity, and travel convenience.`
      });
    }

    const summary = data.choices?.[0]?.message?.content?.trim();

    if (!summary) {
      return res.json({
        summary: `This itinerary includes ${names}. It is arranged based on your selected photography preferences, location popularity, and travel convenience.`
      });
    }

    res.json({ summary });
  } catch (error) {
    console.error("AI summary error:", error);

    const names = (req.body?.recommendations || []).map((r) => r.name).join(", ");
    return res.json({
      summary: names
        ? `This itinerary includes ${names}. It is arranged based on your selected photography preferences, location popularity, and travel convenience.`
        : "No itinerary available yet."
    });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`iTrip backend listening on http://localhost:${PORT}`);
});