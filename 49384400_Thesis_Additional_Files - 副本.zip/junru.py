import json
import math
import csv
from pathlib import Path
from statistics import mean

import matplotlib.pyplot as plt

DATA_PATH = Path("backend/data/brisbane_photo_spots.json")
OUTPUT_DIR = Path("experiment_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

TOP_K = 4


def load_spots():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def to_minutes(time_str: str) -> int:
    h, m = map(int, time_str.split(":"))
    return h * 60 + m


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(dlon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return r * c


def normalize_score(value, min_val=0, max_val=100):
    if value is None:
        return 0.0
    value = float(value)
    if value <= min_val:
        return 0.0
    if value >= max_val:
        return 1.0
    return (value - min_val) / (max_val - min_val)


def get_time_category(preferences):
    tags = preferences.get("preferred_tags", [])

    if "sunrise" in tags:
        return "sunrise"
    if "sunset" in tags:
        return "sunset"
    if "night" in tags:
        return "night"

    start = preferences.get("start_time", "15:00")
    minutes = to_minutes(start)

    if minutes < 420:
        return "sunrise"
    if 960 <= minutes <= 1140:
        return "sunset"
    if minutes > 1140:
        return "night"
    return "daytime"


def get_photo_style_from_tags(tags):
    styles = []

    if "sunset" in tags and "city" in tags:
        styles.append("sunset_skyline")
    if "night" in tags and "city" in tags:
        styles.append("night_cityscape")
    if "river" in tags:
        styles.append("river_reflection")
    if "architecture" in tags:
        styles.append("architecture")
    if "lookout" in tags:
        styles.append("lookout")
    if "nature" in tags:
        styles.append("nature_walk")
    if "bridge" in tags:
        styles.append("bridge_view")

    return list(dict.fromkeys(styles))


def compute_tag_match(spot, preferences):
    pref_tags = preferences.get("preferred_tags", [])
    spot_tags = spot.get("tags", [])
    if not pref_tags:
        return 0.0
    matches = sum(1 for tag in pref_tags if tag in spot_tags)
    return matches / len(pref_tags)


def compute_photo_style_match(spot, preferences):
    user_styles = get_photo_style_from_tags(preferences.get("preferred_tags", []))
    spot_styles = spot.get("photo_styles", [])
    if not user_styles:
        return 0.0
    matches = sum(1 for s in user_styles if s in spot_styles)
    return matches / len(user_styles)


def compute_time_match(spot, preferences):
    time_category = get_time_category(preferences)
    best_time = spot.get("best_time", [])

    if time_category == "sunset":
        base = normalize_score(spot.get("golden_hour_score", 0))
        if "sunset" in best_time or "golden_hour" in best_time:
            base = max(base, 0.85)
        return base

    if time_category == "night":
        base = normalize_score(spot.get("night_score", 0))
        if "night" in best_time or "blue_hour" in best_time:
            base = max(base, 0.85)
        return base

    if time_category == "sunrise":
        if "sunrise" in best_time:
            return 0.95
        if "morning" in best_time:
            return 0.75
        return 0.25

    if "daytime" in best_time:
        return 0.85
    if "morning" in best_time:
        return 0.65
    return 0.45


def compute_weather_suitability(spot, weather_data):
    if not weather_data:
        return 0.5

    cloud = float(weather_data.get("clouds_percent", 50))
    rain_prob = float(weather_data.get("rain_probability_percent", 0))
    visibility_km = float(weather_data.get("visibility_km", 10))

    pref = spot.get("weather_preferences", {})
    max_cloud = float(pref.get("max_cloud_cover", 100))
    max_rain = float(pref.get("max_rain_probability", 100))
    min_visibility = float(pref.get("min_visibility_km", 0))

    score = 1.0

    if cloud > max_cloud:
        score -= min((cloud - max_cloud) / 100, 0.30)

    if rain_prob > max_rain:
        score -= min((rain_prob - max_rain) / 100, 0.40)

    if visibility_km < min_visibility:
        score -= min((min_visibility - visibility_km) / 10, 0.30)

    styles = spot.get("photo_styles", [])

    if "sunset_skyline" in styles:
        if cloud > 80:
            score -= 0.20
        if visibility_km < 5:
            score -= 0.12

    if "night_cityscape" in styles:
        if rain_prob > 50:
            score -= 0.18
        if visibility_km < 4:
            score -= 0.08

    if "river_reflection" in styles:
        if rain_prob > 50:
            score -= 0.12

    if "lookout" in styles:
        if visibility_km < 5:
            score -= 0.15

    return max(0.0, min(1.0, score))


def compute_popularity_score(spot):
    return normalize_score(spot.get("popularity", 0))


def compute_proximity_score(start_location, spot):
    distance_km = haversine_km(
        start_location["lat"],
        start_location["lng"],
        spot["lat"],
        spot["lng"],
    )
    proximity = max(0.0, 1 - distance_km / 20)
    return proximity, distance_km


def score_spot(spot, preferences, weather_context, method):
    tag_match = compute_tag_match(spot, preferences)
    photo_style_match = compute_photo_style_match(spot, preferences)
    time_match = compute_time_match(spot, preferences)
    weather_suitability = compute_weather_suitability(spot, weather_context)
    popularity_score = compute_popularity_score(spot)
    proximity_score, distance_km = compute_proximity_score(preferences["start_location"], spot)

    if method == "base":
        score = 0.60 * popularity_score + 0.40 * proximity_score

    elif method == "photo":
        score = (
            0.25 * tag_match
            + 0.40 * photo_style_match
            + 0.20 * popularity_score
            + 0.15 * proximity_score
        )

    elif method == "time":
        score = (
            0.20 * tag_match
            + 0.30 * photo_style_match
            + 0.30 * time_match
            + 0.10 * popularity_score
            + 0.10 * proximity_score
        )

    elif method == "weather":
        score = (
            0.15 * tag_match
            + 0.20 * photo_style_match
            + 0.20 * time_match
            + 0.35 * weather_suitability
            + 0.10 * proximity_score
        )

    elif method == "full":
        score = (
            0.18 * tag_match
            + 0.28 * photo_style_match
            + 0.24 * time_match
            + 0.22 * weather_suitability
            + 0.05 * popularity_score
            + 0.03 * proximity_score
        )
    else:
        raise ValueError(f"Unknown method: {method}")

    return {
        **spot,
        "distance_km": round(distance_km, 2),
        "score": round(score * 100, 2),
        "tag_match": tag_match,
        "photo_style_match": photo_style_match,
        "time_match": time_match,
        "weather_suitability": weather_suitability,
    }


def reorder_itinerary_greedy(itinerary, start_location):
    if not itinerary:
        return []

    remaining = itinerary[:]
    ordered = []
    current_lat = start_location["lat"]
    current_lng = start_location["lng"]

    while remaining:
        next_spot = min(
            remaining,
            key=lambda s: haversine_km(current_lat, current_lng, s["lat"], s["lng"])
        )
        ordered.append(next_spot)
        current_lat, current_lng = next_spot["lat"], next_spot["lng"]
        remaining.remove(next_spot)

    return ordered


def generate_itinerary(spots, preferences, weather_context, method, max_locations):
    scored = [score_spot(s, preferences, weather_context, method) for s in spots]
    scored.sort(key=lambda x: x["score"], reverse=True)

    start_minutes = to_minutes(preferences["start_time"])
    end_minutes = to_minutes(preferences["end_time"])
    total_available = max(end_minutes - start_minutes, 0)

    picked = []
    used_minutes = 0

    for spot in scored:
        stay = int(spot.get("average_visit_minutes", 30))
        estimated_travel = 20

        if len(picked) >= max_locations:
            break
        if used_minutes + stay + estimated_travel > total_available and picked:
            continue

        picked.append(spot)
        used_minutes += stay + estimated_travel

    return reorder_itinerary_greedy(picked, preferences["start_location"])


def precision_at_k(pred_ids, relevant_ids, k):
    pred = pred_ids[:k]
    if not pred:
        return 0.0
    hits = sum(1 for x in pred if x in relevant_ids)
    return hits / k


def average_precision_at_k(pred_ids, relevant_ids, k):
    pred = pred_ids[:k]
    hits = 0
    score = 0.0
    for i, p in enumerate(pred, start=1):
        if p in relevant_ids:
            hits += 1
            score += hits / i
    if not relevant_ids:
        return 0.0
    return score / min(len(relevant_ids), k)


def dcg_at_k(pred_ids, relevant_ids, k):
    dcg = 0.0
    for i, p in enumerate(pred_ids[:k], start=1):
        rel = 1 if p in relevant_ids else 0
        dcg += rel / math.log2(i + 1)
    return dcg


def ndcg_at_k(pred_ids, relevant_ids, k):
    ideal_len = min(len(relevant_ids), k)
    if ideal_len == 0:
        return 0.0
    ideal_dcg = sum(1 / math.log2(i + 1) for i in range(1, ideal_len + 1))
    if ideal_dcg == 0:
        return 0.0
    return dcg_at_k(pred_ids, relevant_ids, k) / ideal_dcg


def compute_schedule_slack_ratio(itinerary, preferences):
    start_minutes = to_minutes(preferences["start_time"])
    end_minutes = to_minutes(preferences["end_time"])
    total_available = max(end_minutes - start_minutes, 0)

    if total_available <= 0:
        return 0.0

    total_needed = 0.0
    for spot in itinerary:
        total_needed += int(spot.get("average_visit_minutes", 30)) + 20

    slack = total_available - total_needed
    return max(0.0, slack / total_available)


def compute_robust_feasibility_score(itinerary, preferences):
    start_minutes = to_minutes(preferences["start_time"])
    end_minutes = to_minutes(preferences["end_time"])
    total_available = max(end_minutes - start_minutes, 0)

    if total_available <= 0:
        return 0.0

    total_needed = 0.0
    for spot in itinerary:
        stay = int(spot.get("average_visit_minutes", 30)) * 1.10
        travel = 20 * 1.20
        total_needed += stay + travel

    slack = total_available - total_needed
    return max(0.0, slack / total_available)


def compute_optimal_time_window_hit_rate(itinerary, preferences):
    if not itinerary:
        return 0.0
    time_category = get_time_category(preferences)
    hits = 0
    for spot in itinerary:
        best_time = spot.get("best_time", [])
        if time_category in best_time:
            hits += 1
        elif time_category == "sunset" and "golden_hour" in best_time:
            hits += 1
        elif time_category == "night" and "blue_hour" in best_time:
            hits += 1
    return hits / len(itinerary)


def compute_average_weather_suitability(itinerary):
    if not itinerary:
        return 0.0
    return mean(spot.get("weather_suitability", 0.0) for spot in itinerary)


def compute_photo_style_hit_rate(itinerary, preferences):
    target_styles = get_photo_style_from_tags(preferences.get("preferred_tags", []))
    if not itinerary:
        return 0.0
    if not target_styles:
        return 0.0

    hits = 0
    for spot in itinerary:
        spot_styles = spot.get("photo_styles", [])
        if any(style in spot_styles for style in target_styles):
            hits += 1
    return hits / len(itinerary)


def compute_total_distance(itinerary, start_location):
    if not itinerary:
        return 0.0

    total = 0.0
    current_lat = start_location["lat"]
    current_lng = start_location["lng"]

    for spot in itinerary:
        total += haversine_km(current_lat, current_lng, spot["lat"], spot["lng"])
        current_lat = spot["lat"]
        current_lng = spot["lng"]

    return total


SCENARIOS = [
    {
        "name": "sunset_city_good_weather",
        "preferences": {
            "preferred_tags": ["sunset", "city", "river"],
            "start_time": "16:30",
            "end_time": "20:00",
            "max_locations": 4,
            "start_location": {"lat": -27.4698, "lng": 153.0251},
        },
        "weather_context": {
            "description": "clear sky",
            "temperature_c": 23,
            "clouds_percent": 20,
            "visibility_km": 10,
            "rain_probability_percent": 0,
        },
        "relevant_ids": [1, 4, 6, 7, 17, 28, 29],
    },
    {
        "name": "night_city_clear",
        "preferences": {
            "preferred_tags": ["night", "city", "bridge"],
            "start_time": "18:30",
            "end_time": "22:00",
            "max_locations": 4,
            "start_location": {"lat": -27.4698, "lng": 153.0251},
        },
        "weather_context": {
            "description": "clear sky",
            "temperature_c": 20,
            "clouds_percent": 15,
            "visibility_km": 9,
            "rain_probability_percent": 0,
        },
        "relevant_ids": [2, 5, 10, 14, 16, 19, 20, 30],
    },
    {
        "name": "sunset_city_poor_visibility",
        "preferences": {
            "preferred_tags": ["sunset", "city", "lookout"],
            "start_time": "16:45",
            "end_time": "19:30",
            "max_locations": 4,
            "start_location": {"lat": -27.4698, "lng": 153.0251},
        },
        "weather_context": {
            "description": "mist",
            "temperature_c": 21,
            "clouds_percent": 85,
            "visibility_km": 3,
            "rain_probability_percent": 20,
        },
        "relevant_ids": [1, 3, 4, 6, 7],
    },
    {
        "name": "architecture_daytime",
        "preferences": {
            "preferred_tags": ["architecture", "city"],
            "start_time": "10:00",
            "end_time": "14:00",
            "max_locations": 4,
            "start_location": {"lat": -27.4698, "lng": 153.0251},
        },
        "weather_context": {
            "description": "broken clouds",
            "temperature_c": 25,
            "clouds_percent": 50,
            "visibility_km": 8,
            "rain_probability_percent": 0,
        },
        "relevant_ids": [12, 15, 21, 24, 25, 26],
    },
    {
        "name": "river_reflection_light_rain",
        "preferences": {
            "preferred_tags": ["river", "city", "night"],
            "start_time": "18:00",
            "end_time": "21:30",
            "max_locations": 4,
            "start_location": {"lat": -27.4698, "lng": 153.0251},
        },
        "weather_context": {
            "description": "light rain",
            "temperature_c": 19,
            "clouds_percent": 70,
            "visibility_km": 6,
            "rain_probability_percent": 55,
        },
        "relevant_ids": [4, 10, 14, 19, 23],
    },
    {
        "name": "sunrise_nature",
        "preferences": {
            "preferred_tags": ["sunrise", "nature", "park"],
            "start_time": "05:30",
            "end_time": "08:30",
            "max_locations": 4,
            "start_location": {"lat": -27.4975, "lng": 153.0137},
        },
        "weather_context": {
            "description": "few clouds",
            "temperature_c": 17,
            "clouds_percent": 25,
            "visibility_km": 10,
            "rain_probability_percent": 0,
        },
        "relevant_ids": [8, 11, 13, 27, 29],
    },
]

METHODS = ["base", "photo", "time", "weather", "full"]


def write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def plot_bar_chart(methods, values, title, ylabel, output_path):
    plt.figure(figsize=(8, 5))
    plt.bar(methods, values)
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel("Method")
    upper = max(values) * 1.15 if max(values) > 0 else 1
    plt.ylim(0, upper)
    for i, v in enumerate(values):
        plt.text(i, v + upper * 0.015, f"{v:.3f}", ha="center")
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()


def plot_grouped_chart(methods, metric_dict, title, output_path):
    metric_names = list(metric_dict.keys())
    n_methods = len(methods)
    n_metrics = len(metric_names)
    width = 0.16
    x = list(range(n_methods))

    plt.figure(figsize=(10.5, 5.8))

    for idx, metric in enumerate(metric_names):
        values = metric_dict[metric]
        offset = (idx - (n_metrics - 1) / 2) * width
        positions = [xi + offset for xi in x]
        plt.bar(positions, values, width=width, label=metric)

    plt.xticks(x, methods)
    plt.ylim(0, 1.05)
    plt.ylabel("Score")
    plt.xlabel("Method")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()


def run_experiments():
    spots = load_spots()

    scenario_rows = []
    summary_rows = []

    for method in METHODS:
        method_metrics = {
            "precision_at_k": [],
            "map_at_k": [],
            "ndcg_at_k": [],
            "schedule_slack_ratio": [],
            "robust_feasibility_score": [],
            "optimal_time_window_hit_rate": [],
            "average_weather_suitability": [],
            "photo_style_hit_rate": [],
            "avg_total_distance_km": [],
        }

        for scenario in SCENARIOS:
            itinerary = generate_itinerary(
                spots=spots,
                preferences=scenario["preferences"],
                weather_context=scenario["weather_context"],
                method=method,
                max_locations=scenario["preferences"]["max_locations"],
            )

            pred_ids = [x["id"] for x in itinerary]
            relevant_ids = scenario["relevant_ids"]

            p_at_k = precision_at_k(pred_ids, relevant_ids, TOP_K)
            map_k = average_precision_at_k(pred_ids, relevant_ids, TOP_K)
            ndcg_k = ndcg_at_k(pred_ids, relevant_ids, TOP_K)
            slack_ratio = compute_schedule_slack_ratio(itinerary, scenario["preferences"])
            robust_score = compute_robust_feasibility_score(itinerary, scenario["preferences"])
            time_hit = compute_optimal_time_window_hit_rate(itinerary, scenario["preferences"])
            weather_avg = compute_average_weather_suitability(itinerary)
            photo_hit = compute_photo_style_hit_rate(itinerary, scenario["preferences"])
            total_distance = compute_total_distance(itinerary, scenario["preferences"]["start_location"])

            method_metrics["precision_at_k"].append(p_at_k)
            method_metrics["map_at_k"].append(map_k)
            method_metrics["ndcg_at_k"].append(ndcg_k)
            method_metrics["schedule_slack_ratio"].append(slack_ratio)
            method_metrics["robust_feasibility_score"].append(robust_score)
            method_metrics["optimal_time_window_hit_rate"].append(time_hit)
            method_metrics["average_weather_suitability"].append(weather_avg)
            method_metrics["photo_style_hit_rate"].append(photo_hit)
            method_metrics["avg_total_distance_km"].append(total_distance)

            scenario_rows.append({
                "method": method,
                "scenario": scenario["name"],
                "recommended_ids": pred_ids,
                f"precision@{TOP_K}": round(p_at_k, 4),
                f"map@{TOP_K}": round(map_k, 4),
                f"ndcg@{TOP_K}": round(ndcg_k, 4),
                "schedule_slack_ratio": round(slack_ratio, 4),
                "robust_feasibility_score": round(robust_score, 4),
                "optimal_time_window_hit_rate": round(time_hit, 4),
                "average_weather_suitability": round(weather_avg, 4),
                "photo_style_hit_rate": round(photo_hit, 4),
                "total_distance_km": round(total_distance, 2),
            })

        summary_rows.append({
            "method": method,
            f"precision@{TOP_K}": round(mean(method_metrics["precision_at_k"]), 4),
            f"map@{TOP_K}": round(mean(method_metrics["map_at_k"]), 4),
            f"ndcg@{TOP_K}": round(mean(method_metrics["ndcg_at_k"]), 4),
            "schedule_slack_ratio": round(mean(method_metrics["schedule_slack_ratio"]), 4),
            "robust_feasibility_score": round(mean(method_metrics["robust_feasibility_score"]), 4),
            "optimal_time_window_hit_rate": round(mean(method_metrics["optimal_time_window_hit_rate"]), 4),
            "average_weather_suitability": round(mean(method_metrics["average_weather_suitability"]), 4),
            "photo_style_hit_rate": round(mean(method_metrics["photo_style_hit_rate"]), 4),
            "avg_total_distance_km": round(mean(method_metrics["avg_total_distance_km"]), 2),
        })

    write_csv(OUTPUT_DIR / "scenario_results.csv", scenario_rows)
    write_csv(OUTPUT_DIR / "summary_results.csv", summary_rows)

    methods = [row["method"] for row in summary_rows]
    precision_values = [row[f"precision@{TOP_K}"] for row in summary_rows]
    map_values = [row[f"map@{TOP_K}"] for row in summary_rows]
    ndcg_values = [row[f"ndcg@{TOP_K}"] for row in summary_rows]

    slack_values = [row["schedule_slack_ratio"] for row in summary_rows]
    robust_values = [row["robust_feasibility_score"] for row in summary_rows]
    time_hit_values = [row["optimal_time_window_hit_rate"] for row in summary_rows]
    weather_values = [row["average_weather_suitability"] for row in summary_rows]
    photo_hit_values = [row["photo_style_hit_rate"] for row in summary_rows]
    distance_values = [row["avg_total_distance_km"] for row in summary_rows]

    plot_grouped_chart(
        methods,
        {
            f"Precision@{TOP_K}": precision_values,
            f"MAP@{TOP_K}": map_values,
            f"nDCG@{TOP_K}": ndcg_values,
        },
        "Recommendation Accuracy Comparison",
        OUTPUT_DIR / "metric_comparison_precision.png",
    )

    plot_grouped_chart(
        methods,
        {
            "Schedule slack": slack_values,
            "Robust feasibility": robust_values,
            "Time-window hit": time_hit_values,
            "Photo-style hit": photo_hit_values,
            "Avg weather suitability": weather_values,
        },
        "Route Quality and Photography Suitability Comparison",
        OUTPUT_DIR / "metric_comparison_feasibility.png",
    )

    plot_bar_chart(
        methods,
        distance_values,
        "Average Total Distance of Itineraries",
        "Distance (km)",
        OUTPUT_DIR / "metric_comparison_quality.png",
    )

    print("\n=== Summary Results ===")
    for row in summary_rows:
        print(row)

    print(f"\nSaved results to: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    run_experiments()