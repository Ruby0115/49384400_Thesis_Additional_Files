# iTrip — Photography-Focused Trip Planning Prototype

A full-stack prototype built with **Node.js + Express + React + Vite + Mapbox GL JS**.

## Features

- Brisbane photo spots dataset (30 locations)
- Mapbox-based interactive map
- Filter by tags, preferred time, max stop count, and start location
- Weather + sunrise/sunset context aggregation
- Simple recommendation scoring and itinerary generation
- Optional OpenAI-powered trip assistant

## Tech stack

- Frontend: React + Vite
- Backend: Node.js + Express
- Map: Mapbox GL JS
- Weather: OpenWeather API
- Solar times: Sunrise-Sunset API
- AI assistant: OpenAI API (optional)

## Project structure

```text
itrip-system/
  frontend/
  backend/
  package.json
```

## 1) Environment variables

Create these files from the examples.

### backend/.env

```bash
PORT=4000
OPENWEATHER_API_KEY=your_openweather_key
OPENAI_API_KEY=your_openai_key
```

### frontend/.env

```bash
VITE_API_BASE_URL=http://localhost:4000
VITE_MAPBOX_TOKEN=your_mapbox_public_token
```

## 2) Install dependencies

From the project root:

```bash
npm install
```

## 3) Run locally

```bash
npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:4000

## 4) Main endpoints

- `GET /api/health`
- `GET /api/photo-spots`
- `GET /api/context?lat=...&lng=...`
- `POST /api/recommend`
- `POST /api/assistant`

## 5) Recommendation payload example

```json
{
  "preferredTags": ["sunset", "river", "city"],
  "preferredTime": "sunset",
  "maxLocations": 4,
  "startLocation": {
    "lat": -27.4975,
    "lng": 153.0137,
    "label": "UQ St Lucia"
  },
  "transportMode": "driving",
  "availableMinutes": 240
}
```

## Notes

- OpenAI is optional. If `OPENAI_API_KEY` is not set, the assistant endpoint returns a readable fallback message.
- Weather context also works without OpenWeather, but the weather block will be omitted.
- The itinerary algorithm is intentionally lightweight for a thesis/demo prototype.
