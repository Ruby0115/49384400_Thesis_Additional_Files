function formatSummary(text) {
  if (!text) return "";

  return String(text)
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/\*(.*?)\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/^[-•]\s+/gm, "")
    .replace(/\n{2,}/g, "\n")
    .trim();
}

export default function RecommendationPanel({
  recommendations,
  selectedSpotId,
  onSelectSpot,
  aiSummary,
  loading,
  weatherContext
}) {
  const cleanSummary = formatSummary(aiSummary);

  return (
    <div className="recommendation-stack fill-height">
      <div className="card section-card flex-card">
        <h3>Recommended spots</h3>

        <div className="section-scroll">
          {loading ? (
            <p className="muted">Generating recommendations...</p>
          ) : recommendations.length === 0 ? (
            <p className="muted">No itinerary yet. Set your preferences and generate one.</p>
          ) : (
            <div className="recommendation-list">
              {recommendations.map((spot, index) => {
                const active = String(selectedSpotId) === String(spot.id);

                return (
                  <button
                    key={spot.id}
                    className={`recommendation-item ${active ? "active" : ""}`}
                    onClick={() => onSelectSpot(spot.id)}
                  >
                    <div className="recommendation-header">
                      <span className="rank-badge">{index + 1}</span>
                      <strong>{spot.name}</strong>
                    </div>

                    <div className="recommendation-meta">
                      <span>Score: {spot.score?.toFixed?.(1) ?? spot.score}</span>
                      <span>Distance: {spot.distance_km ?? "-"} km</span>
                      <span>Best: {spot.best_time?.join(", ") || "-"}</span>
                    </div>

                    <div className="recommendation-badges">
                      <SmallMetric label="Photo style" value={spot.explainability?.photo_style_match} />
                      <SmallMetric label="Time" value={spot.explainability?.time_match} />
                      <SmallMetric label="Weather" value={spot.explainability?.weather_suitability} />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="card section-card">
        <h3>Weather-aware recommendation context</h3>
        {weatherContext ? (
          <div className="meta-list compact-meta">
            <span>Weather: {weatherContext.description || "N/A"}</span>
            <span>Temperature: {weatherContext.temperature_c ?? "N/A"} °C</span>
            <span>Cloud cover: {weatherContext.clouds_percent ?? "N/A"}%</span>
            <span>Visibility: {weatherContext.visibility_km ?? "N/A"} km</span>
            <span>Rain indicator: {weatherContext.rain_probability_percent ?? 0}%</span>
          </div>
        ) : (
          <p className="muted">Weather-aware context will appear after itinerary generation.</p>
        )}
      </div>

      <div className="card section-card">
        <h3>AI trip summary</h3>
        {cleanSummary ? (
          <p className="summary-text">{cleanSummary}</p>
        ) : (
          <p className="muted">
            Generate an itinerary to see a natural language trip summary.
          </p>
        )}
      </div>
    </div>
  );
}

function SmallMetric({ label, value = 0 }) {
  const safeValue = Number.isFinite(Number(value)) ? Number(value) : 0;

  return (
    <span className="mini-metric">
      {label}: {safeValue.toFixed(0)}
    </span>
  );
}