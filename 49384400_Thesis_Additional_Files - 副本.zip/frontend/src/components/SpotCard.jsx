export default function SpotCard({ spot, score, distanceKm, breakdown, selected, onClick }) {
  return (
    <button className={`spot-card ${selected ? 'selected' : ''}`} onClick={onClick}>
      <div className="spot-card-header">
        <strong>{spot.name}</strong>
        {typeof score === 'number' ? <span className="score-pill">{score.toFixed(2)}</span> : null}
      </div>
      <div className="spot-tags">
        {spot.tags.map((tag) => (
          <span key={tag} className="tag-pill">
            {tag}
          </span>
        ))}
      </div>
      <p>{spot.description}</p>
      <div className="spot-meta">
        <span>Best: {(spot.best_time || []).join(', ')}</span>
        <span>Popularity: {spot.popularity}</span>
        {typeof distanceKm === 'number' ? <span>~{distanceKm.toFixed(1)} km</span> : null}
      </div>
      {breakdown ? (
        <small>
          Tag {breakdown.tagScore} · Light {breakdown.lightingScore} · Proximity {breakdown.proximityScore}
        </small>
      ) : null}
    </button>
  );
}
