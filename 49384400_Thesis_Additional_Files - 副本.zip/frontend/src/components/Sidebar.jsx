import { useMemo } from "react";

const ALL_TAGS = [
  "sunrise",
  "sunset",
  "night",
  "city",
  "river",
  "bridge",
  "park",
  "architecture",
  "nature",
  "lookout",
  "street",
  "art"
];

export default function Sidebar({
  preferences,
  onChange,
  onGenerate,
  loading,
  weather,
  sun,
  contextLoading,
  onStartLocationChange
}) {
  const selectedTags = useMemo(() => preferences.preferred_tags || [], [preferences]);

  function updateField(key, value) {
    onChange({
      ...preferences,
      [key]: value
    });
  }

  function toggleTag(tag) {
    const exists = selectedTags.includes(tag);
    const nextTags = exists
      ? selectedTags.filter((t) => t !== tag)
      : [...selectedTags, tag];

    updateField("preferred_tags", nextTags);
  }

  function updateStartLocation(key, value) {
    const next = {
      ...preferences.start_location,
      [key]: Number(value)
    };
    onChange({
      ...preferences,
      start_location: next
    });
  }

  function applyStartLocation() {
    const { lat, lng } = preferences.start_location;
    if (Number.isFinite(lat) && Number.isFinite(lng)) {
      onStartLocationChange(lat, lng);
    }
  }

  return (
    <div className="sidebar-stack">
      <div className="card">
        <h3>Trip preferences</h3>

        <label className="field">
          <span>Start time</span>
          <input
            type="time"
            value={preferences.start_time}
            onChange={(e) => updateField("start_time", e.target.value)}
          />
        </label>

        <label className="field">
          <span>End time</span>
          <input
            type="time"
            value={preferences.end_time}
            onChange={(e) => updateField("end_time", e.target.value)}
          />
        </label>

        <label className="field">
          <span>Max locations</span>
          <input
            type="number"
            min="1"
            max="8"
            value={preferences.max_locations}
            onChange={(e) => updateField("max_locations", Number(e.target.value))}
          />
        </label>

        <div className="field">
          <span>Photography tags</span>
          <div className="tag-grid">
            {ALL_TAGS.map((tag) => {
              const active = selectedTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  className={`tag-chip ${active ? "active" : ""}`}
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>

        <button className="primary-btn" onClick={onGenerate} disabled={loading}>
          {loading ? "Generating..." : "Generate itinerary"}
        </button>
      </div>

      <div className="card">
        <h3>Start location</h3>

        <div className="inline-fields">
          <label className="field">
            <span>Lat</span>
            <input
              type="number"
              step="0.0001"
              value={preferences.start_location.lat}
              onChange={(e) => updateStartLocation("lat", e.target.value)}
            />
          </label>

          <label className="field">
            <span>Lng</span>
            <input
              type="number"
              step="0.0001"
              value={preferences.start_location.lng}
              onChange={(e) => updateStartLocation("lng", e.target.value)}
            />
          </label>
        </div>

        <button className="secondary-btn" onClick={applyStartLocation}>
          Update context
        </button>
      </div>

      <div className="card">
        <h3>Live context</h3>
        {contextLoading ? (
          <p className="muted">Loading weather and sun data...</p>
        ) : (
          <div className="meta-list">
            <span>Weather: {weather?.description || "N/A"}</span>
            <span>Temp: {weather?.temperature_c ?? "N/A"} °C</span>
            <span>Cloud: {weather?.clouds_percent ?? "N/A"}%</span>
            <span>Visibility: {weather?.visibility_km ?? "N/A"} km</span>
            <span>Rain indicator: {weather?.rain_probability_percent ?? 0}%</span>
            <span>Sunrise: {sun?.sunrise_local || "N/A"}</span>
            <span>Sunset: {sun?.sunset_local || "N/A"}</span>
          </div>
        )}
      </div>
    </div>
  );
}