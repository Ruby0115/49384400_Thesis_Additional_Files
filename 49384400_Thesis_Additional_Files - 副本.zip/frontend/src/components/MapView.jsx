import { useEffect, useRef } from "react";
import mapboxgl from "mapbox-gl";

mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN || "";

const ROUTE_SOURCE_ID = "itrip-route-source";
const ROUTE_LAYER_ID = "itrip-route-layer";

export default function MapView({
  spots,
  recommendations,
  selectedSpotId,
  onSelectSpot,
  startLocation,
  routeGeoJSON
}) {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const markerMapRef = useRef(new Map());
  const popupMapRef = useRef(new Map());
  const startMarkerRef = useRef(null);

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [153.0251, -27.4698],
      zoom: 11.5
    });

    map.addControl(new mapboxgl.NavigationControl(), "top-right");

    map.on("load", () => {
      if (!map.getSource(ROUTE_SOURCE_ID)) {
        map.addSource(ROUTE_SOURCE_ID, {
          type: "geojson",
          data: {
            type: "Feature",
            geometry: {
              type: "LineString",
              coordinates: []
            },
            properties: {}
          }
        });
      }

      if (!map.getLayer(ROUTE_LAYER_ID)) {
        map.addLayer({
          id: ROUTE_LAYER_ID,
          type: "line",
          source: ROUTE_SOURCE_ID,
          layout: {
            "line-join": "round",
            "line-cap": "round"
          },
          paint: {
            "line-color": "#2563eb",
            "line-width": 5,
            "line-opacity": 0.85
          }
        });
      }
    });

    mapRef.current = map;

    return () => {
      markerMapRef.current.forEach((marker) => marker.remove());
      markerMapRef.current.clear();
      popupMapRef.current.clear();

      if (startMarkerRef.current) {
        startMarkerRef.current.remove();
        startMarkerRef.current = null;
      }

      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;

    markerMapRef.current.forEach((marker) => marker.remove());
    markerMapRef.current.clear();
    popupMapRef.current.clear();

    const recommendedIds = new Set(recommendations.map((r) => String(r.id)));

    spots.forEach((spot) => {
      const isRecommended = recommendedIds.has(String(spot.id));
      const isSelected = String(selectedSpotId) === String(spot.id);
      const rank = recommendations.findIndex((r) => String(r.id) === String(spot.id)) + 1;

      const el = document.createElement("button");
      el.type = "button";
      el.className = `custom-marker ${isRecommended ? "recommended" : ""} ${isSelected ? "selected" : ""}`;
      el.title = spot.name;
      el.innerHTML = `<span>${isRecommended ? rank : "•"}</span>`;

      const popup = new mapboxgl.Popup({ offset: 18 }).setHTML(`
        <div style="min-width: 220px">
          <strong>${spot.name}</strong>
          <p style="margin:8px 0 6px; font-size:13px; line-height:1.4;">${spot.description || ""}</p>
          <p style="margin:0; font-size:12px;">Photo styles: ${(spot.photo_styles || []).join(", ") || "-"}</p>
          <p style="margin:4px 0 0; font-size:12px;">Best time: ${(spot.best_time || []).join(", ") || "-"}</p>
        </div>
      `);

      el.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelectSpot(spot.id);
      });

      const marker = new mapboxgl.Marker(el)
        .setLngLat([spot.lng, spot.lat])
        .setPopup(popup)
        .addTo(mapRef.current);

      markerMapRef.current.set(String(spot.id), marker);
      popupMapRef.current.set(String(spot.id), popup);
    });
  }, [spots, recommendations, selectedSpotId, onSelectSpot]);

  useEffect(() => {
    if (!mapRef.current) return;

    if (startMarkerRef.current) {
      startMarkerRef.current.remove();
      startMarkerRef.current = null;
    }

    const startEl = document.createElement("div");
    startEl.className = "start-marker";
    startEl.title = "Start location";

    const marker = new mapboxgl.Marker(startEl)
      .setLngLat([startLocation.lng, startLocation.lat])
      .setPopup(new mapboxgl.Popup({ offset: 18 }).setText("Start location"))
      .addTo(mapRef.current);

    startMarkerRef.current = marker;
  }, [startLocation]);

  useEffect(() => {
    if (!mapRef.current) return;

    const updateRoute = () => {
      const source = mapRef.current?.getSource(ROUTE_SOURCE_ID);
      if (!source) return;

      source.setData(
        routeGeoJSON || {
          type: "Feature",
          geometry: { type: "LineString", coordinates: [] },
          properties: {}
        }
      );

      const coords = routeGeoJSON?.geometry?.coordinates || [];
      if (coords.length >= 2) {
        const bounds = new mapboxgl.LngLatBounds();
        coords.forEach((coord) => bounds.extend(coord));
        mapRef.current.fitBounds(bounds, {
          padding: 80,
          maxZoom: 13.5,
          duration: 900
        });
      }
    };

    if (mapRef.current.isStyleLoaded()) {
      updateRoute();
    } else {
      mapRef.current.once("idle", updateRoute);
    }
  }, [routeGeoJSON]);

  useEffect(() => {
    if (!mapRef.current || !selectedSpotId) return;

    const spot = spots.find((s) => String(s.id) === String(selectedSpotId))
      || recommendations.find((s) => String(s.id) === String(selectedSpotId));

    if (!spot) return;

    mapRef.current.easeTo({
      center: [spot.lng, spot.lat],
      zoom: 13.5,
      offset: [0, 80],
      duration: 900,
      essential: true
    });

    const popup = popupMapRef.current.get(String(selectedSpotId));
    const marker = markerMapRef.current.get(String(selectedSpotId));

    if (popup && marker) {
      popup.setLngLat(marker.getLngLat()).addTo(mapRef.current);
    }
  }, [selectedSpotId, spots, recommendations]);

  return <div ref={mapContainerRef} className="map-container" />;
}