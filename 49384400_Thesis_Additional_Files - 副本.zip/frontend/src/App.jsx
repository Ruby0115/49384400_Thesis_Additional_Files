import { useEffect, useMemo, useState } from "react";
import MapView from "./components/MapView";
import Sidebar from "./components/Sidebar";
import RecommendationPanel from "./components/RecommendationPanel";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";

const defaultPrefs = {
  preferred_tags: ["sunset", "city"],
  start_time: "15:00",
  end_time: "20:00",
  max_locations: 4,
  start_location: {
    lat: -27.4698,
    lng: 153.0251
  }
};

export default function App() {
  const [spots, setSpots] = useState([]);
  const [selectedSpotId, setSelectedSpotId] = useState(null);
  const [preferences, setPreferences] = useState(defaultPrefs);
  const [recommendations, setRecommendations] = useState([]);
  const [routeGeoJSON, setRouteGeoJSON] = useState(null);
  const [weather, setWeather] = useState(null);
  const [sun, setSun] = useState(null);
  const [recommendWeatherContext, setRecommendWeatherContext] = useState(null);
  const [aiSummary, setAiSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [contextLoading, setContextLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchSpots();
    fetchContext(defaultPrefs.start_location.lat, defaultPrefs.start_location.lng);
  }, []);

  const selectedSpot = useMemo(
    () =>
      recommendations.find((s) => String(s.id) === String(selectedSpotId)) ||
      spots.find((s) => String(s.id) === String(selectedSpotId)) ||
      null,
    [spots, recommendations, selectedSpotId]
  );

  async function fetchSpots() {
    try {
      const res = await fetch(`${API_BASE_URL}/api/spots`);
      const data = await res.json();
      setSpots(data);
    } catch {
      setError("Failed to load photo spots.");
    }
  }

  async function fetchContext(lat, lng) {
    try {
      setContextLoading(true);

      const [weatherRes, sunRes] = await Promise.all([
        fetch(`${API_BASE_URL}/api/weather?lat=${lat}&lng=${lng}`),
        fetch(`${API_BASE_URL}/api/sun?lat=${lat}&lng=${lng}`)
      ]);

      const weatherData = await weatherRes.json();
      const sunData = await sunRes.json();

      setWeather(weatherData);
      setSun(sunData);
    } catch {
      setError("Failed to load weather or sun data.");
    } finally {
      setContextLoading(false);
    }
  }

  async function handleGenerate() {
    try {
      setLoading(true);
      setError("");
      setAiSummary("");
      setRouteGeoJSON(null);
      setRecommendWeatherContext(null);

      const recRes = await fetch(`${API_BASE_URL}/api/recommend`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(preferences)
      });

      const recData = await recRes.json();

      if (!recRes.ok) {
        throw new Error(recData.error || "Failed to generate recommendations");
      }

      const ranked = recData.recommendations || [];
      setRecommendWeatherContext(recData.weather_context || null);

      let finalRecommendations = ranked;
      let finalRouteGeoJSON = null;

      if (ranked.length > 0) {
        const dirRes = await fetch(`${API_BASE_URL}/api/directions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            startLocation: preferences.start_location,
            recommendations: ranked,
            profile: "driving"
          })
        });

        const dirData = await dirRes.json();

        if (dirRes.ok) {
          finalRecommendations = dirData.orderedRecommendations || ranked;
          finalRouteGeoJSON = dirData.routeGeoJSON || null;
        } else {
          console.error("Directions error:", dirData);
        }
      }

      setRecommendations(finalRecommendations);
      setRouteGeoJSON(finalRouteGeoJSON);

      if (finalRecommendations.length > 0) {
        setSelectedSpotId(finalRecommendations[0].id);
      } else {
        setSelectedSpotId(null);
      }

      try {
        const summaryRes = await fetch(`${API_BASE_URL}/api/ai-summary`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            preferences,
            recommendations: finalRecommendations
          })
        });

        const summaryData = await summaryRes.json();
        setAiSummary(summaryData.summary || "");
      } catch {
        setAiSummary("");
      }
    } catch (err) {
      setError(err.message || "Failed to generate itinerary.");
    } finally {
      setLoading(false);
    }
  }

  function handlePreferencesChange(nextPrefs) {
    setPreferences(nextPrefs);
  }

  function handleStartLocationChange(lat, lng) {
    const next = {
      ...preferences,
      start_location: { lat, lng }
    };
    setPreferences(next);
    fetchContext(lat, lng);
  }

  return (
    <div className="app-page">
      <header className="topbar">
        <div className="topbar-inner">
          <div>
            <h1>iTrip</h1>
            <p>Photography-focused trip planning for Brisbane</p>
          </div>
          <div className="topbar-badge">Weather-aware photo route planner</div>
        </div>
      </header>

      <main className="layout">
        <aside className="sidebar-column">
          <div className="sidebar-sticky">
            <Sidebar
              preferences={preferences}
              onChange={handlePreferencesChange}
              onGenerate={handleGenerate}
              loading={loading}
              weather={weather}
              sun={sun}
              contextLoading={contextLoading}
              onStartLocationChange={handleStartLocationChange}
            />
          </div>
        </aside>

        <section className="content-column">
          <div className="map-card">
            <MapView
              spots={spots}
              recommendations={recommendations}
              selectedSpotId={selectedSpotId}
              onSelectSpot={setSelectedSpotId}
              startLocation={preferences.start_location}
              routeGeoJSON={routeGeoJSON}
            />
          </div>

          <div className="content-grid">
            <RecommendationPanel
              recommendations={recommendations}
              selectedSpotId={selectedSpotId}
              onSelectSpot={setSelectedSpotId}
              aiSummary={aiSummary}
              loading={loading}
              weatherContext={recommendWeatherContext}
            />

            <div className="details-stack">
              <div className="card details-card">
                <h3>Selected spot</h3>
                {selectedSpot ? (
                  <div className="spot-detail">
                    <h4>{selectedSpot.name}</h4>
                    <p>{selectedSpot.description}</p>

                    <div className="meta-group">
                      <div className="metric-pill">
                        Score: {selectedSpot.score?.toFixed?.(1) ?? selectedSpot.score}
                      </div>
                      <div className="metric-pill">
                        Distance: {selectedSpot.distance_km ?? "-"} km
                      </div>
                      <div className="metric-pill">
                        Stay: {selectedSpot.average_visit_minutes} mins
                      </div>
                    </div>

                    <div className="detail-block">
                      <div className="detail-title">Photography profile</div>
                      <div className="meta-list">
                        <span>Photo styles: {(selectedSpot.photo_styles || []).join(", ") || "-"}</span>
                        <span>Viewpoint type: {selectedSpot.viewpoint_type || "-"}</span>
                        <span>Recommended lens: {(selectedSpot.recommended_lens || []).join(", ") || "-"}</span>
                        <span>Best time: {(selectedSpot.best_time || []).join(", ") || "-"}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="muted">Select a location on the map or generate a route.</p>
                )}
              </div>

              <div className="card">
                <h3>Why this spot</h3>
                {selectedSpot ? (
                  <div className="score-bars">
                    <ScoreBar label="Tag match" value={selectedSpot.explainability?.tag_match} />
                    <ScoreBar label="Photo style match" value={selectedSpot.explainability?.photo_style_match} />
                    <ScoreBar label="Time match" value={selectedSpot.explainability?.time_match} />
                    <ScoreBar label="Weather suitability" value={selectedSpot.explainability?.weather_suitability} />
                    <ScoreBar label="Popularity" value={selectedSpot.explainability?.popularity_score} />
                    <ScoreBar label="Proximity" value={selectedSpot.explainability?.proximity_score} />
                  </div>
                ) : (
                  <p className="muted">Generate an itinerary to see explainability scores.</p>
                )}
              </div>
            </div>
          </div>

          {error ? <div className="error-banner">{error}</div> : null}
        </section>
      </main>
    </div>
  );
}

function ScoreBar({ label, value = 0 }) {
  const safeValue = Number.isFinite(Number(value)) ? Number(value) : 0;

  return (
    <div className="score-row">
      <div className="score-label-wrap">
        <span className="score-label">{label}</span>
        <span className="score-value">{safeValue.toFixed(1)}</span>
      </div>
      <div className="score-track">
        <div
          className="score-fill"
          style={{ width: `${Math.max(0, Math.min(100, safeValue))}%` }}
        />
      </div>
    </div>
  );
}